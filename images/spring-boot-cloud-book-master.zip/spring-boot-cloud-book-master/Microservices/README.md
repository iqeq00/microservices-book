# Overview

| 文件                            | 内容                     | 课程                                  |
| :------------------------------ | :----------------------- | :------------------------------------ |
| Microservice and Monolithic.md  | 微服务架构和单体应用架构 | 4_微服务重要概念与权威解读            |
|                                 |                          | 5_解读微服务重要论文                  |
| Microservice Characteristics.md | 微服务架构特征           | 6_深刻解读Martin Fowler微服务经典文章 |
| Decentralized Governance.md     | 微服务治理与去中心化     | 7_微服务数据治理与去中心化解读        |
| Evolutionary Design.md          | 微服务演进式设计与优缺点 | 8_微服务演进式设计与优缺点剖析        |
| Macro Control.md                | 微服务宏观把控与深入     | 9_微服务宏观把控与深入剖析            |

